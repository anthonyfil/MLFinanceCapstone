import pandas
import os
from random import randint
class sheet:
    def __init__(self, t, ad):
        self.headers = ["date"]
        self.rows = []
        self.data = []
        self.ticker = t
        self. adsh = ad
    def addData(self, row, column, dat):
        c = 0;
        r = 0;
        if column in self.headers:
            c = self.headers.index(str(column))-1   
        else:
            self.headers.append(str(column))
            l = []
            for i in range(0,len(self.rows)):
                l.append("nil")
            self.data.append(l)
            c = self.headers.index(str(column))-1
        #print(self.headers, self.rows, self.data)
        if str(row) in self.rows:
            r = self.rows.index(str(row))   
        else:
            self.rows.append(str(row))
            for i in range(0,len(self.headers) - 1):
                self.data[i].append("nil")
            r = self.rows.index(str(row))
        #print(self.headers, self.rows, self.data)
        self.data[c][r] = str(dat)
    def ToFile(self):
        os.remove(self.ticker + ".txt")
        f = open(self.ticker + ".txt", 'a')
        l1 = ""
        for h in self.headers:
            l1 = l1 + h + ","
        l1 = l1[:-1]
        l1 = l1 + "\n"
        f.write(l1)
        for i in range(0, len(self.rows)):
            l =  str(self.rows[i]) + ","
            for j in range(0, len(self.headers)-1):
                l = l + str(self.data[j][i]) + ","
            l = l[:-1]
            l = l + "\n"
            f.write(l )
        f.close()
    def FromFile(self):
        with open(self.ticker + ".txt", 'r') as f:
            lines = f.readlines()
            if(len(lines) >= 2):
                hs = lines[0].replace('\n', '').split(',')
                for i in range(1, len(lines)):
                    thisl = lines[i].replace('\n', '').split(',')
                    date = thisl[0]
                    for j in range(1, len(thisl)):
                        self.addData(date,hs[j], thisl[j])
            else:
                self.headers = ["date"]
                self.rows = []
                self.data = []
            f.close()       

    def PrintStruct(self):
        l1 = ""
        for h in s.headers:
            l1 = l1 + h + ","
        print(l1 + "\n")
        for i in range(0, len(s.rows)):
            l =  str(s.rows[i]) + ","
            for j in range(0, len(s.headers)-1):
                l = l + str(s.data[j][i]) + ","
            print(l + "\n")

folders =["2018q1\\","2018q2\\","2018q3\\","2018q4\\","2017q1\\","2017q2\\","2017q3\\","2017q4\\","2016q1\\","2016q2\\","2016q3\\","2016q4\\","2015q1\\","2015q2\\","2015q3\\","2015q4\\"]

adshs = [[],
         [],
         [],
         [],
         [],
         [],
         [],
         [], 
         [],
         [],
         [],
         [],
         [], 
         [],
         [], 
         [],# chevron
         [], #walmart
         [], #IBM
         [], #merck
         [],#dow
         [],  # cola
         [], # cisco
         [], #walgreens
         [], #Intel       
        ]
tickers = ["SALESFORCE.COM, INC.",
           "HOME DEPOT, INC.",
           "MICROSOFT CORP",
           "MCDONALDS CORP",
           "AMGEN INC",
           "BOEING CO",
           "CATERPILLAR INC",
           "HONEYWELL INTERNATIONAL INC",
           "TRAVELERS COMPANIES, INC.",
           "APPLE INC",
           "JOHNSON & JOHNSON",
           "WALT DISNEY CO",
           "3M CO",
           "PROCTER & GAMBLE CO",
           "NIKE, INC.",
           "CHEVRON CORP",
           "WALMART INC.",
           "INTERNATIONAL BUSINESS MACHINES CORP",
           "MERCK & CO., INC.",
           "DOW INC.",
           "COCA COLA CO",
           "CISCO SYSTEMS, INC.",
           "WALGREENS BOOTS ALLIANCE, INC.",
           "INTEL CORP",
           ]
for fold in folders:
    print("On Folder" + fold)
    valuesDF = pandas.read_csv(fold + "num.txt", sep='\t', lineterminator='\n', low_memory=False)
    compDF = pandas.read_csv(fold + "sub.txt", sep='\t', lineterminator='\n', low_memory=False)
    for i in range(0, len(compDF["name"])):
        if compDF["name"][i] in tickers:
            t = tickers.index(compDF["name"][i])
            adshs[t].append(compDF["adsh"][i])
    for s in tickers:
        f = open(s + ".txt", 'a')
        f.close()
    """
    adshs.append("temp")  
    for i in range(0, len(valuesDF["adsh"])):
        print(valuesDF["adsh"][i])

        if valuesDF[1][i] in tickers:
            adshs[i] =  valuesDF["adsh"][i];
            print(valuesDF[][i], valuesDF["adsh"][i])
    """  
    for i in range(0, len(valuesDF["adsh"])):
        for a in range(0, len(adshs)):
            if valuesDF["adsh"][i] in adshs[a]:
                print(tickers[a],str(valuesDF["ddate"][i]), str(valuesDF["tag"][i]),str(valuesDF["value"][i]))
                index = adshs[a].index(valuesDF["adsh"][i])
                s = sheet(tickers[a], adshs[a][index])
                s.FromFile()
                s.addData(valuesDF["ddate"][i], valuesDF["tag"][i],valuesDF["value"][i])
                #print("Pre-Save")
                #s.PrintStruct()
                s.ToFile()
                s.FromFile()
                #print("Post-Save")
                #s.PrintStruct()
        
